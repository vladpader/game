﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Timers;

namespace ObjectCaptureGame
{
    public class MainForm : Form
    {
        //  Игровые переменные

        // Игрок - прямоугольник 20x20 пикселей
        private Rectangle player;

        // Массив объектов для сбора (максимум 50)
        private Rectangle[] objects;
        private const int MaxObjects = 50;

        // Генератор случайных чисел для спавна объектов
        private Random random = new Random();

        // Границы игрового поля (не путать с размерами формы)
        private Rectangle gameBounds;

        // Область отображения счета (верхняя часть экрана)
        private Rectangle scoreArea;

        // Игровые параметры
        private int score;          // Текущий счет
        private int timeLeft = 60;  // Оставшееся время (60 секунд)
        private int spawnInterval = 1000; // Интервал спавна (начальный - 1 сек)
        private int objectsCount;   // Текущее количество объектов

        // Таймеры
        private System.Timers.Timer gameTimer;  // Основной игровой таймер
        private System.Timers.Timer spawnTimer; // Таймер спавна объектов

        // Кисти для отрисовки
        private SolidBrush playerBrush = new SolidBrush(Color.Blue);
        private SolidBrush objectBrush = new SolidBrush(Color.Red);
        private SolidBrush textBrush = new SolidBrush(Color.Black);
        private Pen borderPen = new Pen(Color.Gray, 2); // Для границ

        // Шрифты для текста
        private Font scoreFont = new Font("Arial", 14, FontStyle.Bold);
        private Font timerFont = new Font("Arial", 14, FontStyle.Bold);

        // Состояние игры
        private bool isGameRunning = false;

        //  Инициализация игры
        public MainForm()
        {
            // Настройка окна игры
            this.Text = "Захват объектов";
            this.ClientSize = new Size(600, 500);
            this.DoubleBuffered = true; // Убираем мерцание
            this.BackColor = Color.White;

            // Определяем границы:
            // - scoreArea - верхняя полоса 40px для счета
            // - gameBounds - основное поле с отступами 10px
            scoreArea = new Rectangle(0, 0, this.ClientSize.Width, 40);
            gameBounds = new Rectangle(
                10, // Отступ слева
                50, // Отступ сверху (40px scoreArea + 10px margin)
                this.ClientSize.Width - 20, // Ширина (600 - 10*2)
                this.ClientSize.Height - 60); // Высота (500 - 40 - 10*2)

            // Создаем игрока по центру поля
            player = new Rectangle(
                gameBounds.Left + gameBounds.Width / 2 - 10, // Центр по X
                gameBounds.Top + gameBounds.Height / 2 - 10, // Центр по Y
                20, 20); // Размер

            // Инициализируем массив объектов
            objects = new Rectangle[MaxObjects];

            // Создаем кнопку старта
            Button startButton = new Button();
            startButton.Text = "Начать игру";
            startButton.Size = new Size(100, 30);
            startButton.Location = new Point(
                this.ClientSize.Width / 2 - 50, // Центр по X
                this.ClientSize.Height / 2 - 15); // Центр по Y
            startButton.Click += StartButton_Click;
            this.Controls.Add(startButton);

            // Настраиваем таймеры
            gameTimer = new System.Timers.Timer(1000); // 1 секунда
            gameTimer.Elapsed += GameTimer_Elapsed;

            spawnTimer = new System.Timers.Timer(spawnInterval);
            spawnTimer.Elapsed += SpawnTimer_Elapsed;
        }

        //  Обработка кнопки старта
        private void StartButton_Click(object sender, EventArgs e)
        {
            // Сбрасываем параметры игры
            isGameRunning = true;
            score = 0;
            timeLeft = 60;
            spawnInterval = 1000;
            objectsCount = 0;

            // Очищаем массив объектов
            for (int i = 0; i < MaxObjects; i++)
                objects[i] = Rectangle.Empty;

            // Запускаем таймеры
            gameTimer.Start();
            spawnTimer.Interval = spawnInterval;
            spawnTimer.Start();

            // Удаляем кнопку старта
            this.Controls.Remove((Button)sender);

            // Создаем первый объект
            SpawnObject();

            // Обновляем экран
            this.Invalidate();
        }

        //  Основной игровой таймер
        private void GameTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            // Уменьшаем оставшееся время
            timeLeft--;

            // Каждые 10 секунд увеличиваем сложность
            if (timeLeft % 10 == 0 && spawnInterval > 200)
            {
                spawnInterval -= 100; // Уменьшаем интервал на 100мс
                spawnTimer.Interval = spawnInterval; // Применяем
            }

            // Проверяем окончание игры
            if (timeLeft <= 0)
            {
                gameTimer.Stop();
                spawnTimer.Stop();
                isGameRunning = false;

                // Показываем результат
                this.Invoke((MethodInvoker)delegate {
                    MessageBox.Show($"Игра окончена! Ваш счет: {score}", "Конец игры");

                    // Возвращаем кнопку старта
                    Button newButton = new Button();
                    newButton.Text = "Начать игру";
                    newButton.Size = new Size(100, 30);
                    newButton.Location = new Point(
                        this.ClientSize.Width / 2 - 50,
                        this.ClientSize.Height / 2 - 15);
                    newButton.Click += StartButton_Click;
                    this.Controls.Add(newButton);
                });
            }

            // Обновляем интерфейс
            this.Invalidate();
        }

        //  Таймер спавна объектов
        private void SpawnTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            // Создаем новый объект, если игра идет и есть место
            if (isGameRunning && objectsCount < MaxObjects)
            {
                SpawnObject();
                this.Invalidate(); // Перерисовываем
            }
        }

        // Генерация нового объекта 
        private void SpawnObject()
        {
            // Проверяем, есть ли свободные места
            if (objectsCount >= MaxObjects) return;

            // Генерируем случайные координаты в пределах игрового поля
            int x = random.Next(gameBounds.Left, gameBounds.Right - 15);
            int y = random.Next(gameBounds.Top, gameBounds.Bottom - 15);

            // Добавляем новый объект в первый свободный слот
            objects[objectsCount] = new Rectangle(x, y, 15, 15);
            objectsCount++; // Увеличиваем счетчик
        }

        //  Отрисовка игры
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            // 1. Рисуем границы игрового поля
            e.Graphics.DrawRectangle(borderPen, gameBounds);

            // 2. Рисуем игрока (синий квадрат)
            e.Graphics.FillRectangle(playerBrush, player);

            // 3. Рисуем все активные объекты (красные квадраты)
            for (int i = 0; i < objectsCount; i++)
                e.Graphics.FillRectangle(objectBrush, objects[i]);

            // 4. Рисуем панель счета (серый фон)
            e.Graphics.FillRectangle(Brushes.LightGray, scoreArea);

            // 5. Выводим текст (счет и время)
            e.Graphics.DrawString($"Счет: {score}", scoreFont, textBrush, 10, 10);
            e.Graphics.DrawString($"Время: {timeLeft}", timerFont, textBrush,
                                this.ClientSize.Width - 120, 10);
        }

        //  Управление персонажем 
        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);

            // Игнорируем нажатия, если игра не идет
            if (!isGameRunning) return;

            // Скорость перемещения - 5 пикселей за нажатие
            const int speed = 5;

            // Обрабатываем нажатые клавиши
            switch (e.KeyCode)
            {
                case Keys.Left: player.X -= speed; break; // Влево
                case Keys.Right: player.X += speed; break; // Вправо
                case Keys.Up: player.Y -= speed; break; // Вверх
                case Keys.Down: player.Y += speed; break; // Вниз
            }

            // Ограничиваем движение границами игрового поля
            player.X = Math.Clamp(player.X,
                                 gameBounds.Left,
                                 gameBounds.Right - player.Width);
            player.Y = Math.Clamp(player.Y,
                                 gameBounds.Top,
                                 gameBounds.Bottom - player.Height);

            // Проверяем столкновения с объектами
            CheckCollisions();

            // Обновляем экран
            this.Invalidate();
        }

        //Проверка столкновений
        private void CheckCollisions()
        {
            // Проверяем все активные объекты
            for (int i = 0; i < objectsCount; i++)
            {
                // Если игрок пересекается с объектом
                if (player.IntersectsWith(objects[i]))
                {
                    score++; // Увеличиваем счет

                    // Удаляем объект, заменяя его последним в массиве
                    objects[i] = objects[objectsCount - 1];
                    objectsCount--; // Уменьшаем счетчик
                }
            }
        }

        //Завершение работы 
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);

            // Останавливаем таймеры при закрытии формы
            gameTimer?.Stop();
            spawnTimer?.Stop();

            // Освобождаем ресурсы
            playerBrush.Dispose();
            objectBrush.Dispose();
            textBrush.Dispose();
            borderPen.Dispose();
            scoreFont.Dispose();
            timerFont.Dispose();
        }
    }
}