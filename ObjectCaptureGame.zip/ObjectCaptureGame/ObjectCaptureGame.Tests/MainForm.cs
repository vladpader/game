﻿// В начало класса MainForm добавьте:

// Для тестирования
using System.Drawing;
using System.Numerics;

public int CurrentScore => score;
public int TimeRemaining => timeLeft;
public bool GameActive => isGameRunning;
public Rectangle PlayerBounds => player;
public Rectangle[] GameObjects => objects;
public int ActiveObjectsCount => objectsCount;
public Rectangle PlayArea => gameBounds;
public int ObjectSpawnInterval => spawnInterval;

public void ForceKeyPress(Keys key) => OnKeyDown(new KeyEventArgs(key));
public void SimulateGameTick() => GameTimer_Elapsed(null, null);
public void TriggerObjectSpawn() => SpawnTimer_Elapsed(null, null);